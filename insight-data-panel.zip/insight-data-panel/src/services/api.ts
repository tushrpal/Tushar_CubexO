
// Mock API service that simulates real API calls
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}

export interface Metric {
  id: string;
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: string;
}

export interface ChartData {
  month: string;
  revenue: number;
  users: number;
}

export interface Transaction {
  id: string;
  customer: string;
  product: string;
  amount: number;
  status: string;
  date: string;
}

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock data (moved from sampleData.ts)
const mockMetrics: Metric[] = [
  {
    id: 'revenue',
    label: 'Sales Revenue',
    value: '$142,350',
    change: '+12.5%',
    trend: 'up' as const,
    icon: 'revenue'
  },
  {
    id: 'users',
    label: 'Active Users',
    value: '8,432',
    change: '+8.2%',
    trend: 'up' as const,
    icon: 'users'
  },
  {
    id: 'orders',
    label: 'Total Orders',
    value: '2,847',
    change: '-2.1%',
    trend: 'down' as const,
    icon: 'orders'
  }
];

const mockChartData: ChartData[] = [
  { month: 'Jan', revenue: 120, users: 2400 },
  { month: 'Feb', revenue: 135, users: 2800 },
  { month: 'Mar', revenue: 110, users: 2200 },
  { month: 'Apr', revenue: 165, users: 3200 },
  { month: 'May', revenue: 180, users: 3600 },
  { month: 'Jun', revenue: 195, users: 3900 }
];

const mockTransactions: Transaction[] = [
  {
    id: '1',
    customer: 'Alice Johnson',
    product: 'Premium Subscription',
    amount: 299,
    status: 'completed',
    date: '2024-01-15'
  },
  {
    id: '2',
    customer: 'Bob Smith',
    product: 'Business Plan',
    amount: 599,
    status: 'pending',
    date: '2024-01-14'
  },
  {
    id: '3',
    customer: 'Carol Wilson',
    product: 'Starter Pack',
    amount: 99,
    status: 'completed',
    date: '2024-01-13'
  },
  {
    id: '4',
    customer: 'David Brown',
    product: 'Enterprise License',
    amount: 1299,
    status: 'failed',
    date: '2024-01-12'
  },
  {
    id: '5',
    customer: 'Emma Davis',
    product: 'Pro Features',
    amount: 199,
    status: 'completed',
    date: '2024-01-11'
  },
  {
    id: '6',
    customer: 'Frank Miller',
    product: 'Add-on Package',
    amount: 149,
    status: 'pending',
    date: '2024-01-10'
  },
  {
    id: '7',
    customer: 'Grace Lee',
    product: 'Monthly Plan',
    amount: 49,
    status: 'completed',
    date: '2024-01-09'
  },
  {
    id: '8',
    customer: 'Henry Taylor',
    product: 'Custom Solution',
    amount: 899,
    status: 'completed',
    date: '2024-01-08'
  }
];

// API methods
export const api = {
  // GET /api/metrics
  async getMetrics(): Promise<ApiResponse<Metric[]>> {
    console.log('API: Fetching metrics...');
    await delay(800); // Simulate network delay
    return {
      data: mockMetrics,
      success: true,
      message: 'Metrics fetched successfully'
    };
  },

  // GET /api/chart-data
  async getChartData(): Promise<ApiResponse<ChartData[]>> {
    console.log('API: Fetching chart data...');
    await delay(600);
    return {
      data: mockChartData,
      success: true,
      message: 'Chart data fetched successfully'
    };
  },

  // GET /api/transactions
  async getTransactions(): Promise<ApiResponse<Transaction[]>> {
    console.log('API: Fetching transactions...');
    await delay(1000);
    return {
      data: mockTransactions,
      success: true,
      message: 'Transactions fetched successfully'
    };
  },

  // GET /api/transactions/:id
  async getTransaction(id: string): Promise<ApiResponse<Transaction | null>> {
    console.log(`API: Fetching transaction ${id}...`);
    await delay(400);
    const transaction = mockTransactions.find(t => t.id === id);
    return {
      data: transaction || null,
      success: !!transaction,
      message: transaction ? 'Transaction found' : 'Transaction not found'
    };
  }
};