
import React from 'react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  isDarkMode?: boolean;
}

export const LoadingSpinner = ({ size = 'md', isDarkMode = false }: LoadingSpinnerProps) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  return (
    <div className="flex items-center justify-center">
      <div
        className={`${sizeClasses[size]} animate-spin rounded-full border-2 border-solid ${
          isDarkMode 
            ? 'border-gray-600 border-t-blue-400' 
            : 'border-gray-300 border-t-blue-600'
        }`}
      />
    </div>
  );
};
