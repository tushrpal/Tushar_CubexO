
import React from 'react';
import { TrendingUp, Users, ShoppingCart, DollarSign } from 'lucide-react';

interface Metric {
  id: string;
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: string;
}

interface MetricsCardsProps {
  data: Metric[];
  isDarkMode: boolean;
}

export const MetricsCards = ({ data, isDarkMode }: MetricsCardsProps) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'revenue': return DollarSign;
      case 'users': return Users;
      case 'orders': return ShoppingCart;
      default: return TrendingUp;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      {data.map((metric, index) => {
        const Icon = getIcon(metric.icon);
        return (
          <div
            key={metric.id}
            className={`${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} 
                       border rounded-xl p-6 hover:shadow-lg transition-all duration-300 hover:scale-105 
                       animate-fade-in`}
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className={`text-sm font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {metric.label}
                </p>
                <p className={`text-2xl font-bold mt-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {metric.value}
                </p>
                <div className="flex items-center mt-2">
                  <TrendingUp 
                    size={16} 
                    className={`mr-1 ${metric.trend === 'up' ? 'text-green-500' : 'text-red-500'} 
                               ${metric.trend === 'down' ? 'rotate-180' : ''}`} 
                  />
                  <span className={`text-sm font-medium ${metric.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {metric.change}
                  </span>
                </div>
              </div>
              <div className={`p-3 rounded-full ${isDarkMode ? 'bg-blue-600/20' : 'bg-blue-100'}`}>
                <Icon className={`w-6 h-6 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
