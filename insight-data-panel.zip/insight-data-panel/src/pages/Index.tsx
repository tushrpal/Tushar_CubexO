import React, { useState } from 'react';
import { Navigation } from '@/components/Navigation';
import { MetricsCards } from '@/components/MetricsCards';
import { ChartSection } from '@/components/ChartSection';
import { DataTable } from '@/components/DataTable';
import { DarkModeToggle } from '@/components/DarkModeToggle';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Report } from '@/components/Report'; // <-- Import your Report component here
import { useMetrics, useChartData, useTransactions } from '@/hooks/useApiData';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [activeSection, setActiveSection] = useState<'home' | 'reports' | 'settings'>('home');
  const { toast } = useToast();

  const { 
    data: metrics, 
    isLoading: metricsLoading, 
    error: metricsError 
  } = useMetrics();

  const { 
    data: chartData, 
    isLoading: chartLoading, 
    error: chartError 
  } = useChartData();

  const { 
    data: transactions, 
    isLoading: transactionsLoading, 
    error: transactionsError 
  } = useTransactions();

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  React.useEffect(() => {
    if (metricsError) {
      toast({
        title: "Error loading metrics",
        description: metricsError.message,
        variant: "destructive",
      });
    }
  }, [metricsError, toast]);

  React.useEffect(() => {
    if (chartError) {
      toast({
        title: "Error loading chart data",
        description: chartError.message,
        variant: "destructive",
      });
    }
  }, [chartError, toast]);

  React.useEffect(() => {
    if (transactionsError) {
      toast({
        title: "Error loading transactions",
        description: transactionsError.message,
        variant: "destructive",
      });
    }
  }, [transactionsError, toast]);

  const isLoading = metricsLoading || chartLoading || transactionsLoading;

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <Navigation 
        activeSection={activeSection} 
        setActiveSection={setActiveSection}
        isDarkMode={isDarkMode}
      />
      
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} animate-fade-in`}>
                Analytics Dashboard
              </h1>
              <p className={`mt-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Monitor your business metrics and performance
              </p>
            </div>
            <DarkModeToggle isDarkMode={isDarkMode} toggleDarkMode={toggleDarkMode} />
          </div>

          {isLoading && (
            <div className="flex justify-center items-center py-12">
              <LoadingSpinner size="lg" isDarkMode={isDarkMode} />
            </div>
          )}

          {!isLoading && (
            <>
              {activeSection === 'home' && (
                <>
                  {/* Metrics Cards */}
                  {metrics && <MetricsCards data={metrics} isDarkMode={isDarkMode} />}

                  {/* Chart Section */}
                  {chartData && <ChartSection data={chartData} isDarkMode={isDarkMode} />}

                  {/* Data Table */}
                  {transactions && <DataTable data={transactions} isDarkMode={isDarkMode} />}
                </>
              )}

              {activeSection === 'reports' && (
                // Pass the chartData as data prop, and isDarkMode
                <Report data={chartData || []} isDarkMode={isDarkMode} />
              )}

              {activeSection === 'settings' && (
                <div className={`p-4 rounded-lg border ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200 text-gray-900'}`}>
                  <h2 className="text-xl font-semibold mb-4">Settings</h2>
                  <p>Settings content goes here...</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
