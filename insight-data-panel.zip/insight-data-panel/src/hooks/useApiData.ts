
import { useQuery } from '@tanstack/react-query';
import { api } from '@/services/api';

export const useMetrics = () => {
  return useQuery({
    queryKey: ['metrics'],
    queryFn: async () => {
      const response = await api.getMetrics();
      if (!response.success) {
        throw new Error(response.message || 'Failed to fetch metrics');
      }
      return response.data;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};

export const useChartData = () => {
  return useQuery({
    queryKey: ['chartData'],
    queryFn: async () => {
      const response = await api.getChartData();
      if (!response.success) {
        throw new Error(response.message || 'Failed to fetch chart data');
      }
      return response.data;
    },
    staleTime: 5 * 60 * 1000,
  });
};

export const useTransactions = () => {
  return useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      const response = await api.getTransactions();
      if (!response.success) {
        throw new Error(response.message || 'Failed to fetch transactions');
      }
      return response.data;
    },
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
};

export const useTransaction = (id: string) => {
  return useQuery({
    queryKey: ['transaction', id],
    queryFn: async () => {
      const response = await api.getTransaction(id);
      if (!response.success) {
        throw new Error(response.message || 'Failed to fetch transaction');
      }
      return response.data;
    },
    enabled: !!id,
  });
};
